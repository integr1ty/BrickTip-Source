<?php
      
     $bannerSQL = "SELECT * FROM `site_banner`";
     $banner = $conn->query($bannerSQL);
     $bannerRow = $banner->fetch_assoc();
  echo '<div class="grid">
<div class="alert success">
The site is in beta!</div>
</div>
    ';
    ?>

<?php
   /*
     $bannerSQL = "SELECT * FROM `site_banner`";
     $banner = $conn->query($bannerSQL);
     $bannerRow = $banner->fetch_assoc();
  echo '<div class="grid">
<div class="alert warning">
'.$bannerRow['text'].'
</div>
</div>
    ';
    ?>

<?php
      
     $bannerSQL = "SELECT * FROM `site_banner`";
     $banner = $conn->query($bannerSQL);
     $bannerRow = $banner->fetch_assoc();
  echo '<div class="grid">
<div class="alert error">
'.$bannerRow['text'].'
</div>
</div>
    '; 
    ?>


<?php
      
   /* $bannerSQL = "SELECT * FROM `sitesettings`";
     $banner = $conn->query($bannerSQL);
     $bannerRow = $banner->fetch_assoc();
  echo '<div class="grid">
<div class="alert warning">
'.$bannerRow['BannerAlertMessage'].'
</div>
</div>
    ';*/
    ?>

<?php
   /* $grab = "SELECT * FROM `sitesettings` DESC LIMIT 1";  
    $query = mysqli_query($conn, $grab);
$info = mysqli_fetch_assoc($query);
$text = $info['BannerAlertMessage'];
  echo "<div class='grid'>
<div class='alert warning'>
$text
</div>
</div>
    ";*/
    ?>
