<?php
include("config.php");

$offline = true;
$sitename = "BrickTIP";
$sitelink = "https://bricktip.robin2.serv00.net/";
  
?>
