I quit.

-Simples