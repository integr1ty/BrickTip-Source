<div class="card forum-links inline">
<div class="content">
<div class="inline">
<a href="/rules">Rules</a>
<span class="divide"></span>
<div class="inline">
<a href="/forum/bookmarks">Bookmarked
</a>
</div>
<a href="/forum/my_posts">My Posts</a>
<a href="/forum/drafts">Drafts</a>
</div>
</div>
</div>