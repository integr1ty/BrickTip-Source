 <?php   include("../SiT_3/configuration.php");
include("adminheader.php");
   ?>
<?php
      
     $bannerSQL = "SELECT * FROM `alert`";
     $banner = $conn->query($bannerSQL);
     $bannerRow = $banner->fetch_assoc();

           
                
            
      ?>
<?php
  
  if(isset($_POST['banner1'])) {
   

   
    $desc = mysqli_real_escape_string($conn,$_POST['banner']);
    $updateSQL = "UPDATE `alert` SET `alert`='$desc'";
    $update = $conn->query($updateSQL);
  }
  ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.js"></script>
    <?php
if(isset($_POST['banner1']) && empty($error)) {
          echo '<div class="site-announcement" style="background: rgb(62, 123, 0); color: rgb(255, 255, 255); font-size: 14px;">
<div class="grid-x align-middle grid-margin-x">
<div class="auto cell">
<b>Successfully changed banner!!</b></div>
</div>
</div>';
        }
        ?>
<?php
  
  if(isset($_POST['banner2'])) {
   

   
    $desc = mysqli_real_escape_string($conn,$_POST['bannertext2']);
    $updateSQL = "UPDATE `sitesettings` SET `BannerAlertMessage2`='$desc'";
    $update = $conn->query($updateSQL);
  }
  ?>
<?php
if(isset($_POST['banner2']) && empty($error)) {
          echo '<div class="site-announcement" style="background: rgb(62, 123, 0); color: rgb(255, 255, 255); font-size: 14px;">
<div class="grid-x align-middle grid-margin-x">
<div class="auto cell">
<b>Successfully changed banner!!</b></div>
</div>
</div>';
        }
        ?>
<title>Site Settings - <?php echo $sitename; ?></title>
<div class="container">
<div class="row">
<div class="col-4">
<h3>Admin</h3>
</div>
<div class="col-8 text-right">
</div>
</div>
<ul class="breadcrumb bg-white">
<li class="breadcrumb-item"><a href="/admin/">Admin</a></li>
<li class="breadcrumb-item active">Site Settings</li>
</ul>
    <div class="card">
        <div class="card-body">
                
                <div class="row">
                    <div class="col-md-4">
                        <strong></strong>
                        <strong>First Alert Message</strong><br>
                      <form action="" method="POST">
                        <textarea class="form-control mb-2" type="text" name="banner" placeholder="Site alert here..." rows="5"><?php echo''.$bannerRow['BannerAlertMessage'].''; ?></textarea>
                      <button class="btn btn-block btn-success mt-1" type="submit" name="banner1">Update</button>
                        </form>
                      
                        <strong></strong>
                        <div class="row">
                            <div class="col-6">
                                
                            </div>
                            <div class="col-6">
                                <label for="alert_text_color"></label><br>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <strong>Maintenance Passwords</strong>
                        <div class="card">
                            <div class="card-body" style="padding:5px;">
                                
                                    <div><small>GoodHill@StaffTeam123</small></div>
                    </div>
                        
                                
                                    
                            </div>
                        </div>
                    </div>
                </div>
                
            
        </div>
    </div>

 <?php include("adminfooter.php");
   ?>